Theme name: Twenty Sixteen
Release number: 1.0
Author:	Zukathemes (Gary Cunningham-Lee)
Author's website: http://zukathemes.com
License: GPL
Tiki version: Tiki 15.x
Source theme author: The WordPress Team
Source theme website: http:wordpress.org
Source theme license: GPL