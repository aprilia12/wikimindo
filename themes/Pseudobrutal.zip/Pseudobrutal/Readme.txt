Theme name: Pseudobrutal
Release number: 1.0
Author:	Zukathemes (Gary Cunningham-Lee)
Author's website: https://zukathemes.com
License: LGPL
Tiki version: Tiki 15.x